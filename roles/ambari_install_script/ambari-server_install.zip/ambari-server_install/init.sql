create database ambari character set utf8;
create user ambari identified by 'k19k19';
grant all privileges on ambari.* to 'ambari'@'localhost' identified BY 'k19k19';
grant all privileges on ambari.* to 'ambari'@'%' identified BY 'k19k19';

create database hive character set utf8;
grant all privileges on hive.* to 'hive'@'localhost' identified BY 'k19k19';
grant all privileges on hive.* to 'hive'@'%' identified BY 'k19k19';
flush privileges;
