#!/bin/bash

#注意：
#mysql中ambari用户和hive用户的密码都设置成了 k19k19
#如果想设置成其他密码请修改 init.sql 脚本的 identified BY 'k19k19' 部分

#mysql所在的主机
hostname=platform-server-1
database=ambari
username=ambari
#mysql中root用户的密码
password=k19k19
port=3306
BATHPATH=$(cd `dirname $0`; pwd)
script_path=${BATHPATH}


#前提：使用我们的ansible跑了系统优化，安装了jdk和mysql
yum install ambari-server -y
mysql -uroot -p$password < $script_path/init.sql
yum install expect -y
yum install mysql-connector-java -y
rm -r /usr/share/java/mysql-connector-java.jar
cp $script_path/mysql-connector-java-5.1.42.jar /usr/share/java/
ln -s /usr/share/java/mysql-connector-java-5.1.42.jar /usr/share/java/mysql-connector-java.jar
expect -c "spawn /usr/sbin/ambari-server setup
    set timeout 30
    expect {
          \"*SELinux*\" {send \"y\r\";exp_continue}
          \"*Customize user account*\" {send \"y\r\";exp_continue}
          \"*Enter user account for*\" {send \"ambari\r\";exp_continue}
          \"*Enter choice*\" {send \"3\r\";exp_continue}
          \"*JAVA_HOME*\" {send \"/opt/java\r\";exp_continue}
          \"*change Oracle JDK*\" {send \"y\r\";exp_continue}
          \"*Enter advanced database configuration*\" {send \"y\r\";exp_continue}
          \"*MySQL / MariaDB*\" {send \"3\r\";exp_continue}
          \"Hostname*\" {send \"$hostname\r\";exp_continue}
          \"*Port*\" {send \"$port\r\";exp_continue}
          \"Database name*\" {send \"$database\r\";exp_continue}
          \"*Username*\" {send \"$username\r\";exp_continue}
          \"*Database Password*\" {send \"$password\r\";exp_continue}
          \"*Re-enter password*\" {send \"$password\r\";exp_continue}
          \"*connection properties*\" {send \"y\r\";exp_continue}
    }"
mysql -uroot -p$password < $script_path/init2.sql
ambari-server start
ambari-server setup --jdbc-db=mysql --jdbc-driver=/usr/share/java/mysql-connector-java.jar

